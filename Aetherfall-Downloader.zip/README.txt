===============================================================================
  AION AETHERFALL 4.8 REPACK - SETUP, SERVER CONTROL & UPDATER (v0.86)
===============================================================================

1. HOW TO INSTALL & PLAY
------------------------
Double-click "Aetherfall Setup.exe".

- Click "DOWNLOAD & INSTALL REPACK" to download and extract Aion Aetherfall 0.86
  automatically (streams directly from Google Drive CDN at full speed, with
  automatic BitTorrent P2P fallback and SHA-256 verification).
- Once installed, use the "Server Control & Play" panel right inside
  "Aetherfall Setup.exe" to:
    1) Start All Services (MariaDB Database + Login + Chat + Game Server)
    2) Launch Aion Aetherfall (opens the graphical game launcher)
    3) Stop All Services safely when you finish playing

2. HOW TO UPDATE TO NEW RELEASES
--------------------------------
Open "Aetherfall Setup.exe" and click "CHECK & INSTALL UPDATES".
It automatically downloads and applies the latest small delta patch (~10-25 MB)
without touching your database, accounts, characters, companions, or settings.

3. COMMUNITY & SUPPORT
----------------------
Discord: https://discord.com/invite/cpRYCRsSnR
GitHub:  https://github.com/AngelShade/Aion-Aetherfall-4.8-Repack

4. OPEN SOURCE TOOLS
--------------------
aria2 1.37.0 (GNU GPL v2+): https://github.com/aria2/aria2/releases/tag/release-1.37.0
7-Zip 26.04 (GNU LGPL):     https://github.com/ip7z/7zip/releases/tag/26.04
See the "licenses" folder for full license notices.
